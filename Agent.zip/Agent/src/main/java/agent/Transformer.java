package agent;

import java.io.*;
import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.*;

import javassist.*;

public class Transformer implements ClassFileTransformer {

    private HashMap<String, Object> config;
    private String configPath;
    private HashMap<String, String> results;
    private String packagePrefix;

    public Transformer(String configFile) throws InterruptedException {
        if (configFile != null) {
            this.configPath = configFile;
        }
    }

    public byte[] transform(ClassLoader loader, String className, Class classBeingRedefined,
                            ProtectionDomain protectionDomain, byte[] classfileBuffer) {
        byte[] byteCode = classfileBuffer;
        if (className.equals("org/apache/commons/lang3/time/FastDateFormat") ||
            className.equals("org/apache/commons/lang3/fixed/time/FastDateFormat")) {
            loadConfig(this.configPath);
            this.packagePrefix = className.replace("/", ".");
            try {
                ClassPool classPool = ClassPool.getDefault();
                classPool.importPackage("java.io");
                CtClass ctClass = classPool.makeClass(new ByteArrayInputStream(classfileBuffer));
                CtMethod[] methods = ctClass.getDeclaredMethods();
                CtConstructor[] constructors = ctClass.getDeclaredConstructors();
                CtField[] fields = ctClass.getDeclaredFields();

                if (!Arrays.asList(fields).toString().contains("results")) {
                    CtClass hashMapClass = ClassPool.getDefault().get("java.util.HashMap");
                    ctClass.addField(new CtField(hashMapClass, "results", ctClass));
                }


                // Initialise the empty results HashMap and instrument constructor
                for (CtConstructor constructor : constructors) {
                    if (constructor.getLongName().equals(this.packagePrefix + "(" +
                            "java.lang.String,java.util.TimeZone,java.util.Locale)")) {

                        constructor.insertAfter(
                                "{$0.results = new java.util.HashMap();" +
                                "$0.results.put(\"pattern\", $1.toString());" +
                                "$0.results.put(\"timeZone\", $2.toString());" +
                                "$0.results.put(\"localeLanguage\", $3.getLanguage().toString());" +
                                "$0.results.put(\"localeCountry\", $3.getCountry().toString());" +
                                "}");
                    }
                }

                // Add a method to the class that will write the results HashMap to a properties file
                CtMethod m = CtNewMethod.make(
                        "public void writeResults(String resultsFilePath) throws FileNotFoundException {\n" +
                                "   java.io.OutputStream output = new java.io.FileOutputStream(resultsFilePath);\n" +
                                "   try {\n" +
                                "       java.util.Properties prop = new java.util.Properties();\n" +
                                "       prop.putAll($0.results);" +
                                "       prop.store(output, null);\n" +
                                "   } catch (IOException io) {\n" +
                                "       io.printStackTrace();\n" +
                                "   }\n" +
                                "}",
                        ctClass);
                if (!Arrays.asList(methods).toString().contains("writeResults")) {
                    ctClass.addMethod(m);
                }
                // Get the variables involved in the format method, including field variables and the return value
                for (CtMethod method : methods) {
                    if (!method.isEmpty() && (method.getLongName().equals(
                            this.packagePrefix + ".format(java.util.Date)"))) {
                        if (this.config.containsKey("mMaxLengthEstimate")) {
                            method.insertBefore("{$0.mMaxLengthEstimate = " + this.config.get("mMaxLengthEstimate") + ";}");
                        }

                        method.insertAfter("{$0.results.put(\"formattedString\", $_);" +
                                 "$0.results.put(\"mMaxLengthEstimate\", String.valueOf($0.mMaxLengthEstimate));" +
                                 "$0.results.put(\"mRules\", java.util.Arrays.toString($0.mRules));" +
                                 "writeResults(\"results.properties\");" +
                                 "$0.cInstanceCache.clear();}");  // Empty cache ready for follow-up
                    }

                    // This method is called upon initialisation of a FastDateFormatter and constructs a list of
                    // rules. These rules are determined by the specified pattern, locale, and time zone, and act as
                    // a set of instructions to convert the given information to a formatted string.
                    if (!method.isEmpty() && (method.getName().equals("parsePattern"))) {
                        if (this.config.containsKey("mRules")) {
                            StringBuilder ruleSB = new StringBuilder();
                            ruleSB.append("{");
                            ruleSB.append(this.packagePrefix + ".Rule[] updatedRules = new " + this.packagePrefix +
                                    ".Rule[]{");
                            ruleSB.append("new " + this.packagePrefix + ".StringLiteral(\"week: '\"), ");
                            ruleSB.append("new " + this.packagePrefix +
                                    ".TwoDigitNumberField(java.util.Calendar.WEEK_OF_YEAR)");
                            if (!this.config.get("mRules").equals("")) {
                                ruleSB.append(", new " + this.packagePrefix + ".StringLiteral(\" -- " +
                                        this.config.get("mRules") + "\")");
                            }
                            ruleSB.append("};");
                            ruleSB.append("java.util.List updatedRulesList = java.util.Arrays.asList(updatedRules);");
                            ruleSB.append("$_ = updatedRulesList;}");
                            method.insertAfter(ruleSB.toString());
                        }
                    }
                }

                byteCode = ctClass.toBytecode();
                ctClass.detach();
            } catch (Throwable ex) {
                System.out.println("Exception: " + ex);
                ex.printStackTrace();
            }
        }
        return byteCode;
    }


    /***
     * Load the configuration file into a HashMap that will store the values to be used for instrumentation.
     * @param configFilePath Path to the configuration properties file
     */
    public void loadConfig(String configFilePath) {
        HashMap<String, Object> config = new HashMap<>();

        try (InputStream input = new FileInputStream(configFilePath)) {

            Properties properties = new Properties();
            properties.load(input);

            for (String propertyKey : properties.stringPropertyNames()) {
                config.put(propertyKey, properties.getProperty(propertyKey));
            }

            this.config = config;
            this.configPath = configFilePath;

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void writeResults(String resultsFilePath) throws FileNotFoundException {
        // Write the contents of results to a properties file. This should contain the value for all
        // variables in the DAG.
        java.io.OutputStream output = new java.io.FileOutputStream(resultsFilePath);
        try {
            Properties prop = new Properties();
            for (String resultsKey : results.keySet()) {
                prop.put(resultsKey, results.get(resultsKey));
            }
            prop.store(output, null);

        } catch (IOException io) {
            io.printStackTrace();
        }

    }

}
