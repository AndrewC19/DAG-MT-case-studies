package agent;

import java.io.IOException;
import java.lang.instrument.Instrumentation;
import java.lang.instrument.UnmodifiableClassException;


public class LoggerAgent {
    public static void premain(String args, Instrumentation instr) throws InterruptedException {
        instr.addTransformer(new Transformer(args));
    }

    public static void agentmain(String args, Instrumentation instr) throws InterruptedException, UnmodifiableClassException {
        Class<?>[] loadedClasses = instr.getAllLoadedClasses();
        Transformer transformer = new Transformer(args);
        instr.addTransformer(transformer, true);
        for (Class<?> loadedClass : loadedClasses) {
            if (loadedClass.toString().equals("class org.apache.commons.lang3.time.FastDateFormat") ||
                loadedClass.toString().equals("class org.apache.commons.lang3.fixed.time.FastDateFormat")) {
                instr.removeTransformer(transformer);
                instr.retransformClasses(loadedClass);
            }
        }
    }
}
